#include "gema.h"

Gema::Gema(int id)
{
    this->id = id;
}
