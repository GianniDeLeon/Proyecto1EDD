#ifndef GEMA_H
#define GEMA_H


class Gema
{
public:
    Gema(int id);
    int id;
};

#endif // GEMA_H
